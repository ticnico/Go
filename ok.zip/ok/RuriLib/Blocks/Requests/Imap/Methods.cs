using MailKit;
using MailKit.Net.Imap;
using MailKit.Net.Proxy;
using MailKit.Search;
using RuriLib.Attributes;
using RuriLib.Functions.Http;
using RuriLib.Functions.Imap;
using RuriLib.Functions.Networking;
using RuriLib.Http.Models;
using RuriLib.Logging;
using RuriLib.Models.Bots;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using RuriLib.Exceptions;
using RuriLib.Extensions;
using RuriLib.Models.Proxies;
using static RuriLib.Functions.Time.TimeConverter;

namespace RuriLib.Blocks.Requests.Imap;

/// <summary>
/// Blocks for working with the IMAP protocol.
/// </summary>
[BlockCategory("IMAP", "Blocks for working with the IMAP protocol", "#93c", "#fff")]
public static class Methods
{
    private static readonly List<string> _subdomains =
        ["mail", "imap-mail", "inbound", "in", "mx", "imap", "imaps", "m"];

    /// <summary>
    /// Connects to an IMAP server by automatically detecting the host and port.
    /// </summary>
    [Block("Connects to an IMAP server by automatically detecting the host and port")]
    public static async Task ImapAutoConnect(BotData data, string email, int timeoutMilliseconds = 60000,
        [BlockParam("Mode", "Choose whether to use only the known entries from imapdomains.dat or all discovery strategies.")]
        ImapAutoConnectMode mode = ImapAutoConnectMode.Full)
    {
        data.Logger.LogHeader();

        var protocolLogger = InitLogger(data);

        var client = new ImapClient(protocolLogger)
        {
            Timeout = timeoutMilliseconds,
            ServerCertificateValidationCallback = (s, c, h, e) => true
        };

        if (data is { UseProxy: true, Proxy: not null })
        {
            client.ProxyClient = MapProxyClient(data.Proxy);
        }

        data.SetObject("imapClient", client);

        var domain = email.Split('@')[1];

        // Try the entries from imapdomains.dat
        var candidates = (await data.Providers.EmailDomains.GetImapServers(domain).ConfigureAwait(false)).ToList();

        foreach (var c in candidates)
        {
            var success = await TryConnect(data, client, domain, c).ConfigureAwait(false);

            if (success)
            {
                return;
            }
        }

        if (mode == ImapAutoConnectMode.KnownServersOnly)
        {
            throw new BlockExecutionException("Exhausted the known IMAP servers from imapdomains.dat, failed to connect!");
        }

        // Thunderbird autoconfig
        candidates.Clear();
        var thunderbirdUrl = $"https://autoconfig.thunderbird.net/v1.1/{domain}";
        try
        {
            var xml = await GetString(data, thunderbirdUrl).ConfigureAwait(false);
            candidates = ImapAutoconfig.Parse(xml);
            data.Logger.Log($"Queried {thunderbirdUrl} and got {candidates.Count} server(s)", LogColors.DarkOrchid);
        }
        catch
        {
            data.Logger.Log($"Failed to query {thunderbirdUrl}", LogColors.DarkOrchid);
        }

        foreach (var c in candidates)
        {
            var success = await TryConnect(data, client, domain, c).ConfigureAwait(false);

            if (success)
            {
                return;
            }
        }

        // Site autoconfig
        candidates.Clear();
        var autoconfigUrl = $"https://autoconfig.{domain}/mail/config-v1.1.xml?emailaddress={email}";
        var autoconfigUrlUnsecure = $"http://autoconfig.{domain}/mail/config-v1.1.xml?emailaddress={email}";
        try
        {
            string xml;

            try
            {
                xml = await GetString(data, autoconfigUrl).ConfigureAwait(false);
            }
            catch
            {
                xml = await GetString(data, autoconfigUrlUnsecure).ConfigureAwait(false);
            }

            candidates = ImapAutoconfig.Parse(xml);
            data.Logger.Log($"Queried {autoconfigUrl} and got {candidates.Count} server(s)", LogColors.DarkOrchid);
        }
        catch
        {
            data.Logger.Log($"Failed to query {autoconfigUrl} (both https and http)", LogColors.DarkOrchid);
        }

        foreach (var c in candidates)
        {
            var success = await TryConnect(data, client, domain, c).ConfigureAwait(false);

            if (success)
            {
                return;
            }
        }

        // Site well-known
        candidates.Clear();
        var wellKnownUrl = $"https://{domain}/.well-known/autoconfig/mail/config-v1.1.xml";
        var wellKnownUrlUnsecure = $"http://{domain}/.well-known/autoconfig/mail/config-v1.1.xml";
        try
        {
            string xml;

            try
            {
                xml = await GetString(data, wellKnownUrl).ConfigureAwait(false);
            }
            catch
            {
                xml = await GetString(data, wellKnownUrlUnsecure).ConfigureAwait(false);
            }

            candidates = ImapAutoconfig.Parse(xml);
            data.Logger.Log($"Queried {wellKnownUrl} and got {candidates.Count} server(s)", LogColors.DarkOrchid);
        }
        catch
        {
            data.Logger.Log($"Failed to query {wellKnownUrl} (both https and http)", LogColors.DarkOrchid);
        }

        foreach (var c in candidates)
        {
            var success = await TryConnect(data, client, domain, c).ConfigureAwait(false);

            if (success)
            {
                return;
            }
        }

        // Try the domain itself and possible subdomains
        candidates.Clear();
        candidates.Add(new HostEntry(domain, 993));
        candidates.Add(new HostEntry(domain, 143));

        foreach (var sub in _subdomains)
        {
            candidates.Add(new HostEntry($"{sub}.{domain}", 993));
            candidates.Add(new HostEntry($"{sub}.{domain}", 143));
        }

        foreach (var c in candidates)
        {
            var success = await TryConnect(data, client, domain, c).ConfigureAwait(false);

            if (success)
            {
                return;
            }
        }

        // Try MX records
        candidates.Clear();
        try
        {
            var mxRecords = await DnsLookup.FromGoogleAsync(domain, "MX", data.Proxy, 30000, data.CancellationToken).ConfigureAwait(false);
            mxRecords.ForEach(r =>
            {
                candidates.Add(new HostEntry(r, 993));
                candidates.Add(new HostEntry(r, 143));
            });

            data.Logger.Log($"Queried the MX records and got {candidates.Count} server(s)", LogColors.DarkOrchid);
        }
        catch
        {
            data.Logger.Log($"Failed to query the MX records", LogColors.DarkOrchid);
        }

        foreach (var c in candidates)
        {
            var success = await TryConnect(data, client, domain, c).ConfigureAwait(false);

            if (success)
            {
                return;
            }
        }

        throw new BlockExecutionException("Exhausted all possibilities, failed to connect!");
    }

    /// <summary>
    /// Connects to an IMAP server by automatically detecting the host and port.
    /// </summary>
    /// <remarks>Backwards-compatible overload without the mode flag.</remarks>
    public static Task ImapAutoConnect(BotData data, string email, int timeoutMilliseconds = 60000)
        => ImapAutoConnect(data, email, timeoutMilliseconds, ImapAutoConnectMode.Full);

    private static async Task<bool> TryConnect(BotData data, ImapClient client, string domain, HostEntry entry)
    {
        data.Logger.Log($"Trying {entry.Host} on port {entry.Port}...", LogColors.DarkOrchid);

        try
        {
            await client.ConnectAsync(entry.Host, entry.Port, MailKit.Security.SecureSocketOptions.Auto, data.CancellationToken).ConfigureAwait(false);
            data.Logger.Log($"Connected! SSL/TLS: {client.IsSecure}", LogColors.DarkOrchid);
            await data.Providers.EmailDomains.TryAddImapServer(domain, entry).ConfigureAwait(false);
            return true;
        }
        catch
        {
            data.Logger.Log("Failed!", LogColors.DarkOrchid);
        }

        return false;
    }

    private static async Task<string> GetString(BotData data, string url)
    {
        using var httpClient = HttpFactory.GetRLHttpClient(data.Proxy, new HttpOptions
        {
            ConnectTimeout = TimeSpan.FromMilliseconds(30000),
            ReadWriteTimeout = TimeSpan.FromMilliseconds(30000)
        });

        using var request = new HttpRequest();
        request.Uri = new Uri(url);

        using var response = await httpClient.SendAsync(request, data.CancellationToken).ConfigureAwait(false);
        var content = response.Content
                      ?? throw new BlockExecutionException("The autoconfig response content is not available");

        return await content.ReadAsStringAsync(data.CancellationToken).ConfigureAwait(false);
    }

    /// <summary>
    /// Connects to an IMAP server.
    /// </summary>
    [Block("Connects to an IMAP server")]
    public static async Task ImapConnect(BotData data, string host, int port, int timeoutMilliseconds = 60000)
    {
        data.Logger.LogHeader();

        var protocolLogger = InitLogger(data);

        var client = new ImapClient(protocolLogger)
        {
            Timeout = timeoutMilliseconds,
            ServerCertificateValidationCallback = (_, _, _, _) => true
        };

        if (data is { UseProxy: true, Proxy: not null })
        {
            client.ProxyClient = MapProxyClient(data.Proxy);
        }

        data.SetObject("imapClient", client);

        await client.ConnectAsync(host, port, MailKit.Security.SecureSocketOptions.Auto, data.CancellationToken).ConfigureAwait(false);
        data.Logger.Log($"Connected to {host} on port {port}. SSL/TLS: {client.IsSecure}", LogColors.DarkOrchid);
    }

    /// <summary>
    /// Disconnects from an IMAP server.
    /// </summary>
    [Block("Disconnects from an IMAP server")]
    public static async Task ImapDisconnect(BotData data)
    {
        data.Logger.LogHeader();

        var client = GetClient(data);

        if (client.IsConnected)
        {
            await client.DisconnectAsync(true, data.CancellationToken).ConfigureAwait(false);
            data.Logger.Log($"Client disconnected", LogColors.DarkOrchid);
        }
        else
        {
            data.Logger.Log($"The client was not connected", LogColors.DarkOrchid);
        }
    }

    /// <summary>
    /// Logs into an account and optionally opens the inbox.
    /// </summary>
    [Block("Logs into an account")]
    public static async Task ImapLogin(BotData data, string email, string password, bool openInbox = true, int timeoutMilliseconds = 10000)
    {
        data.Logger.LogHeader();

        var client = GetClient(data);
        client.AuthenticationMechanisms.Remove("XOAUTH2");

        using var cts = new CancellationTokenSource(timeoutMilliseconds);
        using var linkedCts = CancellationTokenSource.CreateLinkedTokenSource(cts.Token, data.CancellationToken);
        await client.AuthenticateAsync(email, password, linkedCts.Token).ConfigureAwait(false);
        data.Logger.Log("Authenticated successfully", LogColors.DarkOrchid);

        if (openInbox)
        {
            var inbox = client.Inbox ?? throw new BlockExecutionException("The inbox folder is not available");
            await inbox.OpenAsync(FolderAccess.ReadWrite, data.CancellationToken).ConfigureAwait(false);
            SetCurrentFolder(data, inbox);
            data.Logger.Log($"Opened the inbox, there are {inbox.Count} total messages", LogColors.DarkOrchid);
        }
    }

    /// <summary>
    /// Gets the protocol log.
    /// </summary>
    [Block("Gets the protocol log", name = "Get Imap Log")]
    public static string ImapGetLog(BotData data)
    {
        data.Logger.LogHeader();

        var protocolLogger = data.TryGetObject<ProtocolLogger>("imapLogger");
        var stream = protocolLogger?.Stream as MemoryStream
            ?? throw new BlockExecutionException("The IMAP protocol logger is not initialized");
        var bytes = stream.ToArray();
        var log = Encoding.UTF8.GetString(bytes);

        data.Logger.Log(log, LogColors.DarkOrchid);

        return log;
    }

    /// <summary>
    /// Opens the inbox folder.
    /// </summary>
    [Block("Opens the inbox folder")]
    public static async Task ImapOpenInbox(BotData data)
    {
        data.Logger.LogHeader();

        var client = GetAuthenticatedClient(data);
        var inbox = client.Inbox ?? throw new BlockExecutionException("The inbox folder is not available");
        await inbox.OpenAsync(FolderAccess.ReadWrite, data.CancellationToken).ConfigureAwait(false);

        SetCurrentFolder(data, inbox);

        data.Logger.Log($"Opened the inbox, there are {inbox.Count} total messages", LogColors.DarkOrchid);
    }

    /// <summary>
    /// Searches for mails in the current folder.
    /// </summary>
    [Block("Searches for mails", extraInfo = "The 'delivered after' expects a Unix timestamp (UTC) in seconds.")]
    public static async Task<List<string>> ImapSearchMails(BotData data, SearchField field1 = SearchField.Subject, string text1 = "",
        SearchField field2 = SearchField.From, string text2 = "", int deliveredAfter = 1)
    {
        data.Logger.LogHeader();

        var folder = GetCurrentFolder(data);

        if (!folder.IsOpen)
        {
            await folder.OpenAsync(FolderAccess.ReadWrite, data.CancellationToken).ConfigureAwait(false);
        }

        SearchQuery query = new DateSearchQuery(SearchTerm.DeliveredAfter, ((long)deliveredAfter).ToDateTimeUtc());

        if (!string.IsNullOrEmpty(text1))
        {
            query = query.And(new TextSearchQuery(MapSearchTerm(field1), text1));
        }

        if (!string.IsNullOrEmpty(text2))
        {
            query = query.And(new TextSearchQuery(MapSearchTerm(field2), text2));
        }

        IList<UniqueId>? mails;

        try
        {
            mails = await folder.SearchAsync(query, data.CancellationToken).ConfigureAwait(false);
        }
        catch
        {
            data.Logger.Log("Search denied by the server", LogColors.DarkOrchid);
            return [];
        }

        var ids = mails.Select(id => id.Id.ToString()).ToList();

        data.Logger.Log($"{ids.Count} mails matched the search", LogColors.DarkOrchid);
        data.Logger.Log(ids, LogColors.DarkOrchid);

        return ids;
    }

    /// <summary>
    /// Gets a text or HTML representation of a mail.
    /// </summary>
    [Block("Gets a text (or HTML) representation of a mail")]
    public static async Task<string> ImapReadMail(BotData data, string id, bool preferHtml = false)
    {
        data.Logger.LogHeader();

        var folder = GetCurrentFolder(data);
        var uniqueId = new UniqueId(uint.Parse(id));
        using var mail = await folder.GetMessageAsync(uniqueId, data.CancellationToken).ConfigureAwait(false);

        var body = mail.TextBody;

        if (string.IsNullOrEmpty(body) || preferHtml)
        {
            body = mail.HtmlBody;
        }

        var output =
            $"""
             From: {mail.From.First()}
             To: {mail.To.First()}
             Subject: {mail.Subject}
             Body:
             {body}
             """;

        data.Logger.Log($"From: {mail.From.First()}", LogColors.DarkOrchid);
        data.Logger.Log($"To: {mail.To.First()}", LogColors.DarkOrchid);
        data.Logger.Log($"Subject: {mail.Subject}", LogColors.DarkOrchid);
        data.Logger.Log("Body:", LogColors.DarkOrchid);
        data.Logger.Log(body, LogColors.DarkOrchid, true);
        return output;
    }

    /// <summary>
    /// Gets a mail in EML format.
    /// </summary>
    [Block("Gets a mail in EML format")]
    public static async Task<byte[]> ImapReadMailRaw(BotData data, string id)
    {
        data.Logger.LogHeader();

        var folder = GetCurrentFolder(data);
        var uniqueId = new UniqueId(uint.Parse(id));
        using var mail = await folder.GetMessageAsync(uniqueId, data.CancellationToken).ConfigureAwait(false);

        using var ms = new MemoryStream();
        await mail.WriteToAsync(ms, data.CancellationToken);
        ms.Seek(0, SeekOrigin.Begin);
        var bytes = ms.ToArray();

        data.Logger.Log($"Received {bytes.Length} bytes", LogColors.DarkOrchid);

        return bytes;
    }

    /// <summary>
    /// Deletes a mail.
    /// </summary>
    [Block("Deletes a mail", name = "Imap Delete Mail")]
    public static async Task ImapDeleteMail(BotData data, string id)
    {
        data.Logger.LogHeader();

        var folder = GetCurrentFolder(data);
        var uniqueId = new UniqueId(uint.Parse(id));
        await folder.AddFlagsAsync(uniqueId, MessageFlags.Deleted, true, data.CancellationToken).ConfigureAwait(false);
        await folder.ExpungeAsync(data.CancellationToken).ConfigureAwait(false);

        data.Logger.Log($"Deleted mail with id {id}", LogColors.DarkOrchid);
    }

    /// <summary>
    /// Gets a list of folders.
    /// </summary>
    [Block("Gets a list of folders", name = "Imap List Folders")]
    public static async Task<List<string>> ListFolders(BotData data)
    {
        data.Logger.LogHeader();

        // We always try to get the cached folders first, since it's
        // improbable that they change during the bot's execution
        var folders = data.TryGetObject<List<IMailFolder>>("imapFolders");

        if (folders is null)
        {
            var client = GetAuthenticatedClient(data);
            folders = [];

            foreach (var personalNamespace in client.PersonalNamespaces)
            {
                try
                {
                    var foldersInNamespace = await client.GetFoldersAsync(personalNamespace, cancellationToken: data.CancellationToken).ConfigureAwait(false);
                    folders.AddRange(foldersInNamespace.ToList());
                }
                catch (ImapCommandException)
                {
                    data.Logger.Log($"Failed to get folders in namespace {personalNamespace}", LogColors.DarkOrchid);
                }
            }

            data.SetObject("imapFolders", folders);
        }

        var folderNames = folders.Select(folder => folder.FullName).ToList();
        data.Logger.Log($"Folders: {folderNames.AsString()}", LogColors.DarkOrchid);
        return folderNames;
    }

    /// <summary>
    /// Opens a folder given its full name.
    /// </summary>
    [Block("Opens a folder given its full name", name = "Imap Open Folder")]
    public static async Task<bool> ImapOpenFolder(BotData data, string folderName, FolderAccess folderAccess = FolderAccess.ReadOnly)
    {
        data.Logger.LogHeader();

        var folders = GetFolders(data);
        var folder = folders.Find(f => f.FullName.Equals(folderName, StringComparison.OrdinalIgnoreCase))
                     ?? throw new BlockExecutionException($"Folder '{folderName}' not found");

        await folder.OpenAsync(folderAccess, data.CancellationToken).ConfigureAwait(false);
        data.Logger.Log(folder.IsOpen
                ? $"Folder '{folder.Name}' is opened (messages: {folder.Count})"
                : $"Folder '{folder.Name}' isn't opening",
            LogColors.DarkOrchid);

        SetCurrentFolder(data, folder);

        return folder.IsOpen;
    }

    /// <summary>
    /// Closes the current folder.
    /// </summary>
    [Block("Close folder", name = "Imap Close Folder")]
    public static async Task ImapCloseFolder(BotData data)
    {
        data.Logger.LogHeader();

        var folder = GetCurrentFolder(data);

        if (folder.IsOpen)
        {
            await folder.CloseAsync();
        }

        SetCurrentFolder(data, null);
        data.Logger.Log($"Folder '{folder.Name}' is closed", LogColors.DarkOrchid);
    }

    /// <summary>
    /// Gets the number of email messages in the current folder.
    /// </summary>
    [Block("Gets the number of email messages in a folder", name = "Imap Get Mail Count")]
    public static async Task<int> GetMailCount(BotData data)
    {
        data.Logger.LogHeader();

        var folder = GetCurrentFolder(data);

        if (!folder.IsOpen)
        {
            await folder.OpenAsync(FolderAccess.ReadOnly, data.CancellationToken).ConfigureAwait(false);
        }

        data.Logger.Log($"Mail count: {folder.Count}", LogColors.DarkOrchid);

        return folder.Count;
    }

    /// <summary>
    /// Gets the id of the last message in the current folder.
    /// </summary>
    [Block("Gets the id of the last message in the current folder", name = "Imap Get Last Message Id")]
    public static async Task<int> GetLastMessageId(BotData data)
    {
        data.Logger.LogHeader();

        var folder = GetCurrentFolder(data);

        if (!folder.IsOpen)
        {
            await folder.OpenAsync(FolderAccess.ReadWrite, data.CancellationToken).ConfigureAwait(false);
        }

        data.Logger.Log($"Last message Id: {folder.Count - 1}", LogColors.DarkOrchid);

        return folder.Count - 1;
    }

    private static ImapClient GetClient(BotData data)
        => data.TryGetObject<ImapClient>("imapClient")
           ?? throw new BlockExecutionException("Connect the IMAP client first!");

    private static ImapClient GetAuthenticatedClient(BotData data)
    {
        var client = GetClient(data);

        if (!client.IsAuthenticated)
        {
            throw new BlockExecutionException("Authenticate the IMAP client first!");
        }

        return client;
    }

    private static List<IMailFolder> GetFolders(BotData data)
        => data.TryGetObject<List<IMailFolder>>("imapFolders")
           ?? throw new BlockExecutionException("Get the list of folders first!");

    private static IMailFolder GetCurrentFolder(BotData data)
        => data.TryGetObject<IMailFolder>("imapCurrentFolder")
           ?? throw new BlockExecutionException("Open a folder first!");

    private static void SetCurrentFolder(BotData data, IMailFolder? folder)
        => data.SetObject("imapCurrentFolder", folder);

    private static IProxyClient MapProxyClient(Proxy proxy)
    {
        if (!proxy.NeedsAuthentication)
        {
            return proxy.Type switch
            {
                ProxyType.Http => new HttpProxyClient(proxy.Host, proxy.Port),
                ProxyType.Socks4 => new Socks4Client(proxy.Host, proxy.Port),
                ProxyType.Socks4a => new Socks4aClient(proxy.Host, proxy.Port),
                ProxyType.Socks5 => new Socks5Client(proxy.Host, proxy.Port),
                _ => throw new NotImplementedException(),
            };
        }

        var credentials = new NetworkCredential(proxy.Username, proxy.Password);

        return proxy.Type switch
        {
            ProxyType.Http => new HttpProxyClient(proxy.Host, proxy.Port, credentials),
            ProxyType.Socks4 => new Socks4Client(proxy.Host, proxy.Port, credentials),
            ProxyType.Socks4a => new Socks4aClient(proxy.Host, proxy.Port, credentials),
            ProxyType.Socks5 => new Socks5Client(proxy.Host, proxy.Port, credentials),
            _ => throw new NotImplementedException(),
        };
    }

    private static SearchTerm MapSearchTerm(SearchField field) => field switch
    {
        SearchField.To => SearchTerm.ToContains,
        SearchField.From => SearchTerm.FromContains,
        SearchField.Subject => SearchTerm.SubjectContains,
        SearchField.Body => SearchTerm.BodyContains,
        _ => throw new NotImplementedException()
    };

    private static ProtocolLogger InitLogger(BotData data)
    {
        var ms = new MemoryStream();
        var protocolLogger = new ProtocolLogger(ms, true);

        // ProtocolLogger automatically disposes of the stream when disposed
        data.SetObject("imapLogger", protocolLogger);

        return protocolLogger;
    }
}
