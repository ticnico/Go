using RuriLib.Attributes;
using RuriLib.Logging;
using RuriLib.Models.Bots;
using System.Collections.Generic;
using System.Linq;

// ReSharper disable once CheckNamespace
namespace RuriLib.Blocks.Functions.Dictionary;

/// <summary>
/// Blocks for working with dictionaries.
/// </summary>
[BlockCategory("Dictionary Functions", "Blocks for working with dictionaries", "#9acd32")]
public static class Methods
{
    /// <summary>
    /// Adds an item to the dictionary.
    /// </summary>
    [Block("Adds an item to the dictionary")]
    public static void AddKeyValuePair(BotData data, [Variable] Dictionary<string, string> dictionary, string key, string value)
    {
        data.Logger.LogHeader();

        dictionary.Add(key, value);
        data.Logger.Log($"Added ({key}, {value})", LogColors.YellowGreen);
    }

    /// <summary>
    /// Removes an item with a given key from the dictionary.
    /// </summary>
    [Block("Removes an item with a given key from the dictionary")]
    public static void RemoveByKey(BotData data, [Variable] Dictionary<string, string> dictionary, string key)
    {
        data.Logger.LogHeader();

        var removed = dictionary.Remove(key);
        data.Logger.Log(removed ? $"Removed the item with key {key}" : $"Could not find an item with key {key}",
            LogColors.YellowGreen);
    }

    /// <summary>
    /// Gets the value of a key in the dictionary.
    /// </summary>
    [Block("Gets a dictionary key by value (old <DICT{value}>)")]
    public static string GetKey(BotData data, [Variable] Dictionary<string, string> dictionary, string value)
    {
        data.Logger.LogHeader();

        var key = dictionary.FirstOrDefault(kvp => kvp.Value == value).Key ?? string.Empty;
        data.Logger.Log($"Got key: {key}", LogColors.YellowGreen);
        return key;
    }
}
