using BCrypt.Net;
using JWT.Algorithms;
using Newtonsoft.Json;
using RuriLib.Attributes;
using RuriLib.Functions.Conversion;
using RuriLib.Functions.Crypto;
using RuriLib.Logging;
using RuriLib.Models.Bots;
using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;

namespace RuriLib.Blocks.Functions.Crypto;

/// <summary>
/// Blocks for executing cryptographic functions.
/// </summary>
[BlockCategory("Crypto", "Blocks for executing cryptographic functions", "#9acd32")]
public static class Methods
{
    /// <summary>
    /// XOR encryption and decryption on byte arrays.
    /// </summary>
    [Block("XOR En-/Decryption on byte arrays", name = "XOR")]
    public static byte[] XOR(BotData data, byte[] bytes, byte[] key)
    {
        data.Logger.LogHeader();

        var xor = RuriLib.Functions.Crypto.Crypto.XOR(bytes, key);
        data.Logger.Log($"XORed the two byte arrays and got {HexConverter.ToHexString(xor)}", LogColors.YellowGreen);
        return xor;
    }

    /// <summary>
    /// XOR encryption and decryption on strings.
    /// </summary>
    [Block("Does a simple XOR En-/Decryption on strings", name = "XOR Strings")]
    public static string XORStrings(BotData data, string text, string key)
    {
        data.Logger.LogHeader();

        var xor = RuriLib.Functions.Crypto.Crypto.XORStrings(text, key);
        data.Logger.Log($"XORed: {text} with {key} with the outcome {xor}", LogColors.YellowGreen);
        return xor;
    }

    /// <summary>
    /// Hashes data using the specified hashing function.
    /// </summary>
    [Block("Hashes data using the specified hashing function")]
    public static byte[] Hash(BotData data, byte[] input, HashFunction hashFunction = HashFunction.MD5)
    {
        data.Logger.LogHeader();

        var hashed = Hash(input, hashFunction);
        data.Logger.Log($"Computed hash: {HexConverter.ToHexString(hashed)}", LogColors.YellowGreen);
        return hashed;
    }

    /// <summary>
    /// Hashes a UTF8 string to a HEX-encoded lowercase string using the specified hashing function.
    /// </summary>
    [Block("Hashes a UTF8 string to a HEX-encoded lowercase string using the specified hashing function")]
    public static string HashString(BotData data, string input, HashFunction hashFunction = HashFunction.MD5)
    {
        data.Logger.LogHeader();

        var hashed = HexConverter.ToHexString(Hash(Encoding.UTF8.GetBytes(input), hashFunction));
        data.Logger.Log($"Computed hash: {hashed}", LogColors.YellowGreen);
        return hashed;
    }

    /// <summary>
    /// Hashes a string using NTLM.
    /// </summary>
    [Block("Hashes a string using NTLM", name = "NTLM Hash")]
    public static byte[] NTLMHash(BotData data, string input)
    {
        data.Logger.LogHeader();

        var hashed = RuriLib.Functions.Crypto.Crypto.NTLM(input);
        data.Logger.Log($"Computed hash: {HexConverter.ToHexString(hashed)}", LogColors.YellowGreen);
        return hashed;
    }

    /// <summary>
    /// Computes the HMAC signature of some data using the specified secret key and hashing function.
    /// </summary>
    [Block("Computes the HMAC signature of some data using the specified secret key and hashing function")]
    public static byte[] Hmac(BotData data, byte[] input, byte[] key, HashFunction hashFunction = HashFunction.MD5)
    {
        data.Logger.LogHeader();

        var hmac = Hmac(input, key, hashFunction);
        data.Logger.Log($"Computed HMAC: {HexConverter.ToHexString(hmac)}", LogColors.YellowGreen);
        return hmac;
    }

    /// <summary>
    /// Computes the HMAC signature as a HEX-encoded lowercase string from a given UTF8 string using the specified key and hashing function.
    /// </summary>
    [Block("Computes the HMAC signature as a HEX-encoded lowercase string from a given UTF8 string using the specified key and hashing function")]
    public static string HmacString(BotData data, string input, byte[] key, HashFunction hashFunction = HashFunction.MD5)
    {
        data.Logger.LogHeader();

        var hmac = HexConverter.ToHexString(Hmac(Encoding.UTF8.GetBytes(input), key, hashFunction));
        data.Logger.Log($"Computed HMAC: {hmac}", LogColors.YellowGreen);
        return hmac;
    }

    private static byte[] Hash(byte[] input, HashFunction function)
    {
        return function switch
        {
            HashFunction.MD4 => RuriLib.Functions.Crypto.Crypto.MD4(input),
            HashFunction.MD5 => RuriLib.Functions.Crypto.Crypto.MD5(input),
            HashFunction.SHA1 => RuriLib.Functions.Crypto.Crypto.SHA1(input),
            HashFunction.SHA256 => RuriLib.Functions.Crypto.Crypto.SHA256(input),
            HashFunction.SHA384 => RuriLib.Functions.Crypto.Crypto.SHA384(input),
            HashFunction.SHA512 => RuriLib.Functions.Crypto.Crypto.SHA512(input),
            _ => throw new NotSupportedException()
        };
    }

    private static byte[] Hmac(string input, byte[] key, HashFunction function)
        => Hmac(Encoding.UTF8.GetBytes(input), key, function);

    private static byte[] Hmac(byte[] input, byte[] key, HashFunction function)
    {
        return function switch
        {
            HashFunction.MD5 => RuriLib.Functions.Crypto.Crypto.HMACMD5(input, key),
            HashFunction.SHA1 => RuriLib.Functions.Crypto.Crypto.HMACSHA1(input, key),
            HashFunction.SHA256 => RuriLib.Functions.Crypto.Crypto.HMACSHA256(input, key),
            HashFunction.SHA384 => RuriLib.Functions.Crypto.Crypto.HMACSHA384(input, key),
            HashFunction.SHA512 => RuriLib.Functions.Crypto.Crypto.HMACSHA512(input, key),
            _ => throw new NotSupportedException()
        };
    }

    /// <summary>
    /// Hashes data using the Scrypt algorithm.
    /// </summary>
    [Block("Hashes data using the Scrypt algorithm")]
    public static string ScryptString(BotData data, string password, string salt, int iterationCount = 16384, int blockSize = 8, int threadCount = 1)
    {
        data.Logger.LogHeader();

        var saltBytes = NormalizeLegacyScryptSalt(salt);
        var hashed = FormatLegacyScryptHash(password, saltBytes, iterationCount, blockSize, threadCount);
        data.Logger.Log($"Computed Scrypt: {hashed}", LogColors.YellowGreen);
        return hashed;
    }

    /// <summary>
    /// Derives a raw key using the Scrypt algorithm and returns it as a HEX-encoded lowercase string.
    /// </summary>
    [Block("Derives a raw key using the Scrypt algorithm and returns it as a HEX-encoded lowercase string",
        name = "Scrypt Derive Key")]
    public static string ScryptDeriveKey(BotData data, string password, string salt, int outputSize = 32,
        int iterationCount = 16384, int blockSize = 8, int threadCount = 1)
    {
        data.Logger.LogHeader();

        var derived = RuriLib.Functions.Crypto.Crypto.Scrypt(
            Encoding.UTF8.GetBytes(password),
            Encoding.UTF8.GetBytes(salt),
            iterationCount,
            blockSize,
            threadCount,
            outputSize);
        var hex = HexConverter.ToHexString(derived);

        data.Logger.Log($"Derived Scrypt key: {hex}", LogColors.YellowGreen);
        return hex;
    }

    private static string FormatLegacyScryptHash(string password, byte[] saltBytes, int iterationCount, int blockSize, int threadCount)
    {
        var derived = RuriLib.Functions.Crypto.Crypto.Scrypt(
            Encoding.UTF8.GetBytes(password),
            saltBytes,
            iterationCount,
            blockSize,
            threadCount);

        return FormattableString.Invariant(
            $"$s2${iterationCount}${blockSize}${threadCount}${Convert.ToBase64String(saltBytes)}${Convert.ToBase64String(derived)}");
    }

    private static byte[] NormalizeLegacyScryptSalt(string salt)
    {
        var saltBytes = new byte[32];
        var providedSaltBytes = Encoding.UTF8.GetBytes(salt);
        Array.Copy(providedSaltBytes, saltBytes, Math.Min(providedSaltBytes.Length, saltBytes.Length));

        return saltBytes;
    }

    /// <summary>
    /// Encrypts data using RSA.
    /// </summary>
    [Block("Encrypts data using RSA", name = "RSA Encrypt")]
    public static byte[] RSAEncrypt(BotData data, byte[] plainText, byte[] modulus, byte[] exponent, bool useOAEP)
    {
        data.Logger.LogHeader();

        var cipherText = RuriLib.Functions.Crypto.Crypto.RSAEncrypt(plainText, modulus, exponent, useOAEP);
        data.Logger.Log($"Encrypted: {HexConverter.ToHexString(cipherText)}", LogColors.YellowGreen);
        return cipherText;
    }

    /// <summary>
    /// Decrypts data using RSA.
    /// </summary>
    [Block("Decrypts data using RSA", name = "RSA Decrypt")]
    public static byte[] RSADecrypt(BotData data, byte[] cipherText, byte[] modulus, byte[] d, bool useOAEP)
    {
        data.Logger.LogHeader();

        var plainText = RuriLib.Functions.Crypto.Crypto.RSADecrypt(cipherText, modulus, d, useOAEP);
        data.Logger.Log($"Decrypted: {HexConverter.ToHexString(plainText)}", LogColors.YellowGreen);
        return plainText;
    }

    /// <summary>
    /// Encrypts data using RSA with PKCS1PAD2.
    /// </summary>
    [Block("Encrypts data using RSA with PKCS1PAD2", name = "RSA PKCS1PAD2")]
    public static byte[] RSAPkcs1Pad2(BotData data, string plainText, string hexModulus, string hexExponent)
    {
        data.Logger.LogHeader();

        var encrypted = RuriLib.Functions.Crypto.Crypto.RSAPkcs1Pad2(plainText, hexModulus, hexExponent);
        data.Logger.Log($"Encrypted: {HexConverter.ToHexString(encrypted)}", LogColors.YellowGreen);
        return encrypted;
    }

    /// <summary>
    /// Generates a PKCS v5 #2.0 key using a Password-Based Key Derivation Function.
    /// </summary>
    [Block("Generates a PKCS v5 #2.0 key using a Password-Based Key Derivation Function", name = "PBKDF2PKCS5")]
    public static byte[] PBKDF2PKCS5(BotData data, byte[] password, byte[]? salt = null, int saltSize = 8,
        int iterations = 1, int keyLength = 16, HashFunction type = HashFunction.SHA1)
    {
        data.Logger.LogHeader();

        var derived = RuriLib.Functions.Crypto.Crypto.PBKDF2PKCS5(password, salt, saltSize, iterations, keyLength, type);
        data.Logger.Log($"Derived: {HexConverter.ToHexString(derived)}", LogColors.YellowGreen);
        return derived;
    }

    /// <summary>
    /// Encrypts data using AES.
    /// </summary>
    [Block("Encrypts data with AES", name = "AES Encrypt")]
    public static byte[] AESEncrypt(BotData data, byte[] plainText, byte[] key, byte[] iv,
        CipherMode mode = CipherMode.CBC, PaddingMode padding = PaddingMode.None, int keySize = 256)
    {
        data.Logger.LogHeader();

        var cipherText = RuriLib.Functions.Crypto.Crypto.AESEncrypt(plainText, key, iv, mode, padding, keySize);
        data.Logger.Log($"Encrypted: {HexConverter.ToHexString(cipherText)}", LogColors.YellowGreen);
        return cipherText;
    }

    /// <summary>
    /// Encrypts a string with AES.
    /// </summary>
    [Block("Encrypts a string with AES", name = "AES Encrypt String")]
    public static byte[] AESEncryptString(BotData data, string plainText, byte[] key, byte[] iv,
        CipherMode mode = CipherMode.CBC, PaddingMode padding = PaddingMode.None, int keySize = 256)
    {
        data.Logger.LogHeader();

        var cipherText = RuriLib.Functions.Crypto.Crypto.AESEncryptString(plainText, key, iv, mode, padding, keySize);
        data.Logger.Log($"Encrypted: {HexConverter.ToHexString(cipherText)}", LogColors.YellowGreen);
        return cipherText;
    }

    /// <summary>
    /// Decrypts data using AES.
    /// </summary>
    [Block("Decrypts data with AES", name = "AES Decrypt")]
    public static byte[] AESDecrypt(BotData data, byte[] cipherText, byte[] key, byte[] iv,
        CipherMode mode = CipherMode.CBC, PaddingMode padding = PaddingMode.None, int keySize = 256)
    {
        data.Logger.LogHeader();

        var plainText = RuriLib.Functions.Crypto.Crypto.AESDecrypt(cipherText, key, iv, mode, padding, keySize);
        data.Logger.Log($"Decrypted: {HexConverter.ToHexString(plainText)}", LogColors.YellowGreen);
        return plainText;
    }

    /// <summary>
    /// Decrypts data with AES to string.
    /// </summary>
    [Block("Decrypts data with AES to string", name = "AES Decrypt String")]
    public static string AESDecryptString(BotData data, byte[] cipherText, byte[] key, byte[] iv,
        CipherMode mode = CipherMode.CBC, PaddingMode padding = PaddingMode.None, int keySize = 256)
    {
        data.Logger.LogHeader();

        var plainText = RuriLib.Functions.Crypto.Crypto.AESDecryptString(cipherText, key, iv, mode, padding, keySize);
        data.Logger.Log($"Decrypted: {plainText}", LogColors.YellowGreen);
        return plainText;
    }

    /// <summary>
    /// Generates a JSON Web Token.
    /// </summary>
    [Block("Generates a JSON Web Token using a secret key, payload, optional extra headers and specified algorithm type",
        name = "JWT Encode", extraInfo = "The header already contains the selected algorithm and token type (JWT) by default. For JWTs using asymmetric key signatures, the secret must be provided in PEM format.")]
    public static string JwtEncode(
        BotData data,
        JwtAlgorithmName algorithm,
        [BlockParam("Secret", "Secret key for symmetric algorithms, or a PEM-formatted private key for asymmetric JWT algorithms.")]
        string secret,
        [BlockParam("Extra Headers", "JSON object string with additional header fields to merge into the JWT header, for example {\"kid\":\"my-key-id\"}.")]
        string extraHeaders = "{}",
        [BlockParam("Payload", "JSON object string representing the JWT payload/claims, for example {\"sub\":\"123\",\"role\":\"admin\"}.")]
        string payload = "{}")
    {
        data.Logger.LogHeader();

        var extraHeadersDictionary = JsonConvert.DeserializeObject<Dictionary<string, object>>(extraHeaders);
        var payloadDictionary = JsonConvert.DeserializeObject<Dictionary<string, object>>(payload);

        ArgumentNullException.ThrowIfNull(extraHeadersDictionary, nameof(extraHeadersDictionary));
        ArgumentNullException.ThrowIfNull(payloadDictionary, nameof(payloadDictionary));

        var encoded = RuriLib.Functions.Crypto.Crypto.JwtEncode(algorithm, secret, extraHeadersDictionary, payloadDictionary);

        data.Logger.Log($"Encoded: {encoded}", LogColors.YellowGreen);

        return encoded;
    }

    /// <summary>
    /// Generates a BCrypt hash from an input and a salt.
    /// </summary>
    [Block("Generates a BCrypt hash from an input and a salt", name = "BCrypt Hash",
        extraInfo = "If you don't have the salt, use the BCrypt Hash (Gen Salt) block")]
    public static string BCryptHash(BotData data, string input, string salt)
    {
        data.Logger.LogHeader();

        var hashed = RuriLib.Functions.Crypto.Crypto.BCryptWithSalt(input, salt);
        data.Logger.Log($"Hashed: {hashed}", LogColors.YellowGreen);

        return hashed;
    }

    /// <summary>
    /// Generates a BCrypt hash from an input by generating a salt.
    /// </summary>
    [Block("Generates a BCrypt hash from an input by generating a salt", name = "BCrypt Hash (Gen Salt)",
        extraInfo = "bcryptjs uses salt revision 2X by default currently")]
    public static string BCryptHashGenSalt(BotData data, string input, int rounds = 10, SaltRevision saltRevision = SaltRevision.Revision2X)
    {
        data.Logger.LogHeader();

        var hashed = RuriLib.Functions.Crypto.Crypto.BCryptGenSalt(input, rounds, saltRevision);
        data.Logger.Log($"Hashed: {hashed}", LogColors.YellowGreen);

        return hashed;
    }

    /// <summary>
    /// Verifies that a BCrypt hash is valid.
    /// </summary>
    [Block("Verifies that a BCrypt hash is valid", name = "BCrypt Verify")]
    public static bool BCryptVerify(BotData data, string input, string hash)
    {
        data.Logger.LogHeader();

        var isValid = RuriLib.Functions.Crypto.Crypto.BCryptVerify(input, hash);
        data.Logger.Log($"BCrypt hash verification result: {isValid}", LogColors.YellowGreen);

        return isValid;
    }

    /// <summary>
    /// Generates an AWS4 Signature from a key, date, region and service.
    /// </summary>
    [Block("Generates an AWS4 Signature from a key, date, region and service", name = "AWS4 Signature",
        extraInfo = "It returns a byte array and it expects the date to be in the following format: YYYYMMDD")]
    public static byte[] AWS4Signature(
        BotData data,
        string key,
        [BlockParam("Date", "Date in AWS Signature V4 format YYYYMMDD, for example 20250130.")]
        string date,
        string region,
        [BlockParam("Service", "AWS service identifier, for example s3, iam, sts, or execute-api.")]
        string service)
    {
        data.Logger.LogHeader();

        var signature = RuriLib.Functions.Crypto.Crypto.AWS4Encrypt(key, date, region, service);
        data.Logger.Log($"Hashed: {HexConverter.ToHexString(signature)}", LogColors.YellowGreen);

        return signature;
    }
}
