using Core.Entities;
using Core.Repositories;
using Microsoft.EntityFrameworkCore;
using System.Collections.ObjectModel;
using System.IO;
using System.Windows.Data;

namespace GoldenBullet.ViewModels
{
    public class WordlistsViewModel : ViewModelBase
    {
        private readonly IWordlistRepository wordlistRepo;
        private bool initialized;

        private ObservableCollection<WordlistEntity> wordlistsCollection;
        public ObservableCollection<WordlistEntity> WordlistsCollection
        {
            get => wordlistsCollection;
            private set
            {
                wordlistsCollection = value;
                OnPropertyChanged();
            }
        }

        public int Total => WordlistsCollection.Count;

        private string searchString = string.Empty;
        public string SearchString
        {
            get => searchString;
            set
            {
                searchString = value;
                OnPropertyChanged();
                CollectionViewSource.GetDefaultView(WordlistsCollection).Refresh();
                OnPropertyChanged(nameof(Total));
            }
        }

        public WordlistsViewModel()
        {
            wordlistRepo = SP.GetService<IWordlistRepository>();
            WordlistsCollection = new();
            _ = InitializeAsync(); // Load on startup so Home shows data immediately
        }

        public async Task InitializeAsync()
        {
            if (!initialized)
            {
                await RefreshListAsync();
                initialized = true;
            }
        }

        private void HookFilters()
        {
            var view = (CollectionView)CollectionViewSource.GetDefaultView(WordlistsCollection);
            view.Filter = WordlistsFilter;
        }

        private bool WordlistsFilter(object item) => (item as WordlistEntity).Name.Contains(searchString, StringComparison.OrdinalIgnoreCase);

        public WordlistEntity GetWordlistByName(string name) => WordlistsCollection.First(w => w.Name == name);

        public Task AddAsync(WordlistEntity wordlist)
        {
            if (WordlistsCollection.Any(w => w.FileName == wordlist.FileName))
            {
                throw new Exception($"Wordlist already present: {wordlist.FileName}");
            }

            WordlistsCollection.Add(wordlist);
            OnPropertyChanged(nameof(Total)); // FIX: notify total changed
            return wordlistRepo.AddAsync(wordlist);
        }

        public async Task RefreshListAsync()
        {
            var items = await wordlistRepo.GetAll().ToListAsync();

            // FIX: Clear and add instead of replacing, so CollectionChanged subscriptions survive
            WordlistsCollection.Clear();
            foreach (var item in items)
                WordlistsCollection.Add(item);

            HookFilters();
            OnPropertyChanged(nameof(Total));
        }

        public async Task UpdateAsync(WordlistEntity wordlist) => await wordlistRepo.UpdateAsync(wordlist);

        public async Task DeleteAsync(WordlistEntity wordlist)
        {
            WordlistsCollection.Remove(wordlist);
            await wordlistRepo.DeleteAsync(wordlist, false);
            OnPropertyChanged(nameof(Total));
        }

        public void DeleteAll()
        {
            WordlistsCollection.Clear();
            wordlistRepo.Purge();
            OnPropertyChanged(nameof(Total));
        }

        public async Task<int> DeleteNotFoundAsync()
        {
            var deleted = 0;

            for (var i = 0; i < WordlistsCollection.Count; i++)
            {
                var wordlist = WordlistsCollection[i];

                if (!File.Exists(wordlist.FileName))
                {
                    await DeleteAsync(wordlist);
                    deleted++;
                    i--;
                }
            }

            return deleted;
        }
    }
}
